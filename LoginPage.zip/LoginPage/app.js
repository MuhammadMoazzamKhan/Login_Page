const logregBox = document.querySelector(".logreg-box");
const loginLink = document.querySelector(".login-link");
const registerLink = document.querySelector(".register-link");
const emailLog = document.getElementById("emailLog");
const passwordLog = document.getElementById("passwordLog");
const emailSign = document.getElementById("emailSign");
const passwordSign = document.getElementById("passwordSign");
const nameSign = document.getElementById("nameSign");
const btnSign = document.getElementById("btnSign");
const btnLog = document.getElementById("btnLog");
const lockshowLog = document.getElementById("lockshow");
const lockshowSign = document.getElementById("lockshow1");


registerLink.addEventListener("click", () => {
    logregBox.classList.add("active");
})
loginLink.addEventListener("click", () => {
    logregBox.classList.remove("active");
})

btnSign.addEventListener("click",()=>{
    let email = emailSign.value;
    let name = nameSign.value;
    let password = passwordSign.value;
    if(/^([0-9a-zA-Z]([-\.\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\w]*[0-9a-zA-Z]\.)+[a-zA-Z]{2,9})$/.test(email) && password.length >=8 && name !== ""){
        localStorage.setItem("email" , email);
        localStorage.setItem("password" , password);
        localStorage.setItem("name",name)
    }else{
        Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'Something went wrong!',
            footer: 'Please Enter a acceptable Name, Email & Password'
          })
        email = "";
        name = "";
        password = '';
    }
})


lockshowLog .style.cursor = "pointer"
lockshowLog .addEventListener('click',()=>{
    if(passwordLog.type == "password"){
        passwordLog.type = "text";
    }else{
        passwordLog.type = "password";
    }
    
})

lockshowSign .style.cursor = "pointer"
lockshowSign .addEventListener('click',()=>{
    if(passwordSign.type == "password"){
        passwordSign.type = "text";
    }else{
        passwordSign.type = "password";
    }
    
})

let acceptable;
btnLog.addEventListener("click",()=>{
    let email = emailLog.value;
    let password= passwordLog.value;
    console.log(email , password)
    if(/^([0-9a-zA-Z]([-\.\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\w]*[0-9a-zA-Z]\.)+[a-zA-Z]{2,9})$/.test(email) && password.length >=8){
        if(email == localStorage.getItem("email") && password == localStorage.getItem("password")){
            Swal.fire({
                title: 'Welcome To Our Website .',
                width: 600,
                padding: '3em',
                color: '#black',
                background: '#fff ',
                backdrop: `
                  url("nyan-cat.gif")
                  left top
                  no-repeat
                `
              })
        }
    }
})
console.log(localStorage.getItem("email"))
console.log(localStorage.getItem("password"))

